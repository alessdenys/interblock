// 中央核心对象
var EDMathUI = /** @class */ function() {
	EDMathUI.view = null;
	EDMathUI.uifontbold = true;
	EDMathUI.uifontitalic = true;
	EDMathUI.image = null;
	EDMathUI.lineType = 0;
	EDMathUI.arrType = 0;
};
